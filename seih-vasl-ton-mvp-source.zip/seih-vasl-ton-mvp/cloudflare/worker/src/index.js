const WALLET = "UQCOQAOcSb1BPRr4f_tCod7KH8rl133P5QqUsSS3-YFojdhW";
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,OPTIONS",
    "access-control-allow-headers": "Content-Type,Authorization"
  }
});
const newId = () => crypto.randomUUID();

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { headers: {
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET,POST,OPTIONS",
      "access-control-allow-headers": "Content-Type,Authorization"
    }});
    if (url.pathname === "/health") return json({ ok: true, service: "SEIH VASL API", stage: "TON-MVP" });
    if (url.pathname === "/api/payment-info") return json({ asset: "TON", wallet: WALLET, verification: "manual" });
    if (url.pathname === "/api/plans") return json([
      { id: "FREE", title: "رایگان", priceTon: "0" },
      { id: "VIP", title: "ویژه", priceTon: null },
      { id: "ULTRA", title: "فوق‌ویژه", priceTon: null }
    ]);

    if (url.pathname === "/api/payments" && request.method === "POST") {
      let body;
      try { body = await request.json(); } catch { return json({ error: "Invalid JSON" }, 400); }
      const plan = String(body.plan || "").toUpperCase();
      const txHash = String(body.txHash || "").trim();
      const amountTon = String(body.amountTon || "").trim();
      if (!["VIP", "ULTRA"].includes(plan)) return json({ error: "Invalid plan" }, 400);
      if (txHash.length < 20 || txHash.length > 160) return json({ error: "Invalid transaction hash" }, 400);
      if (!amountTon || !/^\\d+(\\.\\d{1,9})?$/.test(amountTon)) return json({ error: "Invalid TON amount" }, 400);
      try {
        const paymentId = newId();
        await env.DB.prepare(
          "INSERT INTO payments (id,plan,amount_ton,destination_wallet,tx_hash,status) VALUES (?,?,?,?,?,'pending')"
        ).bind(paymentId, plan, amountTon, WALLET, txHash).run();
        return json({ ok: true, paymentId, status: "pending" }, 201);
      } catch {
        return json({ error: "Hash already submitted or database error" }, 409);
      }
    }

    if (url.pathname.startsWith("/api/admin/")) {
      const token = request.headers.get("Authorization") || "";
      if (!env.ADMIN_TOKEN || token !== `Bearer ${env.ADMIN_TOKEN}`) return json({ error: "Unauthorized" }, 401);

      if (url.pathname === "/api/admin/summary") {
        const users = await env.DB.prepare("SELECT COUNT(*) AS count FROM users").first();
        const pending = await env.DB.prepare("SELECT COUNT(*) AS count FROM payments WHERE status='pending'").first();
        const approved = await env.DB.prepare("SELECT COUNT(*) AS count FROM payments WHERE status='approved'").first();
        return json({ users: users?.count ?? 0, pendingPayments: pending?.count ?? 0, approvedPayments: approved?.count ?? 0 });
      }
      if (url.pathname === "/api/admin/payments" && request.method === "GET") {
        const status = url.searchParams.get("status") || "pending";
        if (!["pending", "approved", "rejected", "all"].includes(status)) return json({ error: "Invalid status" }, 400);
        const sql = status === "all"
          ? "SELECT * FROM payments ORDER BY created_at DESC LIMIT 200"
          : "SELECT * FROM payments WHERE status=? ORDER BY created_at DESC LIMIT 200";
        const result = status === "all" ? await env.DB.prepare(sql).all() : await env.DB.prepare(sql).bind(status).all();
        return json(result.results || []);
      }
      const match = url.pathname.match(/^\\/api\\/admin\\/payments\\/([a-f0-9-]+)\\/decision$/i);
      if (match && request.method === "POST") {
        let body;
        try { body = await request.json(); } catch { return json({ error: "Invalid JSON" }, 400); }
        const decision = String(body.decision || "");
        if (!["approved", "rejected"].includes(decision)) return json({ error: "Invalid decision" }, 400);
        const result = await env.DB.prepare(
          "UPDATE payments SET status=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=? AND status='pending'"
        ).bind(decision, match[1]).run();
        if (!result.meta?.changes) return json({ error: "Not found or already reviewed" }, 404);
        return json({ ok: true, status: decision });
      }
    }
    return json({ error: "Not found" }, 404);
  }
};
