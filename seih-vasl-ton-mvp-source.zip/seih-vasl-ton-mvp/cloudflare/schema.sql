CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, email TEXT UNIQUE, display_name TEXT,
  plan TEXT NOT NULL DEFAULT 'FREE', status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS subscriptions (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL, plan TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', starts_at TEXT, expires_at TEXT,
  provider_reference TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS servers (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, region TEXT,
  mode TEXT NOT NULL DEFAULT 'GLOBAL', enabled INTEGER NOT NULL DEFAULT 0,
  endpoint_configured INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY, user_id TEXT, plan TEXT NOT NULL,
  asset TEXT NOT NULL DEFAULT 'TON', amount_ton TEXT,
  destination_wallet TEXT NOT NULL, tx_hash TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending', admin_note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_at TEXT
);
