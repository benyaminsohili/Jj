# SEIH VASL — TON MVP

Development starter for the SEIH VASL Android app, Cloudflare Worker API, D1 schema,
admin payment review panel, and GitHub Actions APK build.

## Included
- Android Compose app shell with FREE / VIP / ULTRA plans
- TON wallet address display and copy
- Transaction-hash submission UI (local placeholder until API URL is configured)
- Cloudflare Worker endpoints to submit payment requests and list/review them
- D1 schema for users, subscriptions, servers, payments
- Admin panel for manual review
- GitHub Actions debug APK workflow

## TON wallet
Inserted exactly as supplied:
`UQCOQAOcSb1BPRr4f_tCod7KH8rl133P5QqUsSS3-YFojdhW`

Verify the address in your own TON wallet before accepting funds or publishing the app.

## Important
This is a development MVP scaffold, not a production VPN and not a production payment processor.
No Xray server is configured, so VPN connectivity is disabled.
TON payments are manually reviewed in this version. Never approve based only on a user-provided
transaction hash; independently verify destination wallet, amount, successful transaction and
that the transaction has not already been used.

## Cloudflare setup
1. Create a Worker and D1 database.
2. Apply `cloudflare/schema.sql`.
3. Replace `database_id` in `cloudflare/worker/wrangler.toml`.
4. Set `ADMIN_TOKEN` as a Worker secret. Never commit it.
5. Deploy the Worker using Wrangler.
6. Use the `workers.dev` URL; no custom domain is needed.
7. Replace `API_BASE_URL` in the Android Gradle file with the deployed Worker URL.

## API
- `GET /health`
- `GET /api/payment-info`
- `GET /api/plans`
- `POST /api/payments` JSON: `{ "plan":"VIP", "amountTon":"...", "txHash":"..." }`
- `GET /api/admin/summary` (admin bearer token)
- `GET /api/admin/payments?status=pending` (admin bearer token)
- `POST /api/admin/payments/{id}/decision` JSON: `{ "decision":"approved" | "rejected" }`

## Build
Open `android/` in Android Studio with JDK 17 and Android SDK 35, or run `gradle assembleDebug`.
GitHub Actions uploads a debug APK for testing. Public release needs secure signing configuration.

## Before launch
Complete Xray/VpnService integration, actual on-chain TON verification, authentication,
subscription activation, payment pricing, admin audit logs, privacy policy, terms and security review.
