package com.seihvasl.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF10243A)
private val Blue = Color(0xFF2D8CFF)
private const val TON_WALLET = "UQCOQAOcSb1BPRr4f_tCod7KH8rl133P5QqUsSS3-YFojdhW"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SeihVaslApp() }
    }
}

@Composable
fun SeihVaslApp() {
    val context = LocalContext.current
    var mode by remember { mutableStateOf("هوشمند") }
    var plan by remember { mutableStateOf("VIP") }
    var txHash by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("برای فعال‌سازی VPN، سرور Xray لازم است.") }
    var showPayment by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Color(0xFF19334F))) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(20.dp))
                Text("سیح وصل", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("SEIH VASL • SMART NETWORK", color = Color(0xFFB7CBE0), fontSize = 12.sp)
                Spacer(Modifier.height(26.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF19334F)),
                    shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("وضعیت اتصال", color = Color.LightGray)
                        Spacer(Modifier.height(10.dp))
                        Text("در انتظار راه‌اندازی", color = Color(0xFFFFD27A), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(status, color = Color(0xFFD7E5F2), fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = { status = "برای اتصال واقعی باید سرور Xray و موتور VPN پیکربندی شوند." },
                            enabled = false, modifier = Modifier.fillMaxWidth()) {
                            Text("اتصال پس از راه‌اندازی سرور")
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text("حالت اتصال", color = Color.White, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("ملی", "جهانی", "هوشمند").forEach {
                        FilterChip(selected = mode == it, onClick = { mode = it }, label = { Text(it) })
                    }
                }
                Spacer(Modifier.height(20.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF19334F)),
                    modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("اشتراک‌ها", color = Color.White, fontWeight = FontWeight.Bold)
                        listOf("FREE", "VIP", "ULTRA").forEach { p ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = plan == p, onClick = { plan = p })
                                Text(p, color = Color.White)
                                Spacer(Modifier.weight(1f))
                                Text(if (p == "FREE") "رایگان" else "پرداخت با TON",
                                    color = Color(0xFFB7CBE0), fontSize = 12.sp)
                            }
                        }
                        Button(onClick = { showPayment = true }, enabled = plan != "FREE",
                            modifier = Modifier.fillMaxWidth()) { Text("پرداخت / حمایت با TON") }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("White DNS • نسخه 0.2.0", color = Color(0xFF8FA8C0), fontSize = 12.sp)
            }
        }

        if (showPayment) {
            AlertDialog(
                onDismissRequest = { showPayment = false },
                title = { Text("پرداخت با TON") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("پلن انتخابی: $plan")
                        Text("مبلغ TON باید پیش از انتشار در تعرفه فروش مشخص شود.", fontSize = 13.sp)
                        Text("آدرس کیف پول", fontWeight = FontWeight.Bold)
                        SelectionContainer { Text(TON_WALLET, fontSize = 12.sp) }
                        OutlinedButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("TON wallet", TON_WALLET))
                            status = "آدرس کیف پول کپی شد."
                        }, modifier = Modifier.fillMaxWidth()) { Text("کپی آدرس") }
                        OutlinedTextField(value = txHash, onValueChange = { txHash = it },
                            label = { Text("شناسه تراکنش") }, modifier = Modifier.fillMaxWidth())
                        Text("در این نسخه پرداخت دستی بررسی می‌شود؛ صرف وارد کردن شناسه به معنی تأیید پرداخت نیست.",
                            fontSize = 12.sp, color = Color.Gray)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        status = if (txHash.isBlank()) "شناسه تراکنش را وارد نکرده‌ای."
                        else "درخواست پرداخت آماده ثبت است؛ ابتدا آدرس API کلودفلر را تنظیم کن."
                        showPayment = false
                    }) { Text("ثبت درخواست") }
                },
                dismissButton = { TextButton(onClick = { showPayment = false }) { Text("بستن") } }
            )
        }
    }
}
